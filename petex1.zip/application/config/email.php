<?php

$config['protocol'] = "smtp";
$config['smtp_host'] = "ssl://smtp.gmail.com";
$config['smtp_port'] = 465;
$config['charset'] = "utf-8";
$config['newline'] = "\r\n";
$config['mailtype'] = "html";

$config['smtp_user'] = "codebusters.solutions@gmail.com";
$config['smtp_pass'] = "codebusterssolution1";

