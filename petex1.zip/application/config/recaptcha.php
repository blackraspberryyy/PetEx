<?php

// To use reCAPTCHA, you need to sign up for an API key pair for your site.
// link: http://www.google.com/recaptcha/admin
$config['recaptcha_site_key'] = '6LfpaDgUAAAAAOov0Q-3G_nsihY3x6KA9BwDHIo0';
$config['recaptcha_secret_key'] = '6LfpaDgUAAAAAGnW21WmLMcgHzQf3ezya4UpKPbs';

// reCAPTCHA supported 40+ languages listed here:
// https://developers.google.com/recaptcha/docs/language
$config['recaptcha_lang'] = 'en';

/* Location: ./application/config/recaptcha.php */