<html>
    <head>
        <title>Sending Contact Us</title>
    </head>
    <body>
        <div id="container">
            <h1>Hello! I am <?= $name ?></h1>

            <div id="body">
                <?= $body ?>
               
            </div>
        </div>
    </body>
</html>