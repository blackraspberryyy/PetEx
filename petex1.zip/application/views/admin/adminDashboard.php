<div class ="side-nav-offset">
    <div class ="container row">
        This is dashboard
    </div>
</div>